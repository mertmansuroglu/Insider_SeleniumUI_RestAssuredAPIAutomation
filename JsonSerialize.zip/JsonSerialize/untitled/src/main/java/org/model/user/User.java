package org.model.user; 
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;
public class User{
    @JsonProperty("Email") 
    public String email;
    @JsonProperty("Username") 
    public String username;
    public String sms_phone;
    @JsonProperty("Committees") 
    public ArrayList<String> committees;
    @JsonProperty("Groups") 
    public ArrayList<String> groups;
    @JsonProperty("Roles") 
    public ArrayList<String> roles;
    public ArrayList<ProfileProperty> profile_properties;
    public String authorized_recipients;
    public boolean send_registration_email;
}
