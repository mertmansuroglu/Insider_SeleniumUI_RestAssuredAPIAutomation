package org.model.questionnaire;
import java.util.ArrayList;

public class Group{
    public int id;
    public ArrayList<Expression> expressions;
    public String logical_operator;
}
