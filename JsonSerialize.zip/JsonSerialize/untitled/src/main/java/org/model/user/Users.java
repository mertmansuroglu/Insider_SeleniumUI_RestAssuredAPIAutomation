package org.model.user; 
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class Users {
    @JsonProperty("Committees") 
    public ArrayList<String> committees;
    @JsonProperty("Groups") 
    public ArrayList<String> groups;
    public ArrayList<Object> profile_properties_custom;
    public ArrayList<User> users;
}
