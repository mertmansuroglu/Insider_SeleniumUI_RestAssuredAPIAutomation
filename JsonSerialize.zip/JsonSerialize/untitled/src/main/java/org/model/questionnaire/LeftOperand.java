package org.model.questionnaire;
public class LeftOperand{
    public int item_id;
    public String operand_type;
    public String profile_key;
    public String permission_key;
}
