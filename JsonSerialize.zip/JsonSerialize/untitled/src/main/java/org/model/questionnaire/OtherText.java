package org.model.questionnaire;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OtherText{
    @JsonProperty("en-US")
    public String en_US;
}
