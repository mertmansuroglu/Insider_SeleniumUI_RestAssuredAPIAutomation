package org.model.questionnaire;
public class RightOperand{
    public String value;
    public String operand_type;
    public int item_id;
    public int choice_id;
    public String answer;
    public String name;
}
