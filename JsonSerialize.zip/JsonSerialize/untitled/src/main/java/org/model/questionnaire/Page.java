package org.model.questionnaire;
import java.util.ArrayList;

public class Page{
    public int id;
    public String title;
    public int position;
    public String page_type;
    public ArrayList<Object> branching_rules;
    public ArrayList<Item> items;
    public IncludeCondition include_condition;
}
