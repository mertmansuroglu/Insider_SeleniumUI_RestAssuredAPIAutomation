package org.model.questionnaire;
public class Flyover{
    public int flyover_id;
    public String term;
    public String definition;
    public int template_id;
    public String flyover_guid;
}
