package org.model.questionnaire;
public class Element{
    public int row;
    public int column;
    public Item item;
}
