package org.model.questionnaire;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StartText{
    @JsonProperty("en-US")
    public String en_US;
}
