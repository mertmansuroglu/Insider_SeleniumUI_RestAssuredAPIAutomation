package org.model.questionnaire;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EndText{
    @JsonProperty("en-US")
    public String en_US;
}
