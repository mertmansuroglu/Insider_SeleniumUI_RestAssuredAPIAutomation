package org.model.questionnaire;

import java.util.Date;

public class ExhibitFolder{
    public int id;
    public String folder_guid;
    public int template_id;
    public String name;
    public Date created_at;
    public Date updated_at;
    public String created_by;
    public String updated_by;
    public boolean is_global_exhibit;
}
