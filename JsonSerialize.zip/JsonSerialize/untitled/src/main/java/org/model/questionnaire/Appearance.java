package org.model.questionnaire;
public class Appearance{
    public boolean show_survey_title;
    public boolean show_page_numbers;
    public boolean show_item_numbers;
    public boolean enable_dynamic_page_numbers;
    public boolean enable_dynamic_item_numbers;
    public boolean is_item_order_randomized;
    public boolean show_validation_error_alert;
    public boolean show_asterisks;
    public boolean show_progress_bar;
    public int progress_bar_orientation;
    public boolean show_compliance_link;
    public boolean allow_accessibility_options;
    public boolean allow_edit_while_active;
}
