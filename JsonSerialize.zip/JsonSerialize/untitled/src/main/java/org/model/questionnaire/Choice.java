package org.model.questionnaire;
public class Choice{
    public int id;
    public Text text;
    public String alias;
    public int position;
    public boolean is_default;
    public boolean is_other;
    public double points;
    public boolean is_none_of_above;
    public boolean enabled;
}
