package org.model.questionnaire;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MidText{
    @JsonProperty("en-US")
    public String en_US;
}
