package org.model.questionnaire;
public class RespondentSettings{
    public boolean allow_back_button;
    public boolean allow_response_reset;
    public boolean allow_complete_response_edit;
    public boolean allow_response_resume;
    public boolean allow_response_save;
    public boolean anonymized;
    public String security_type;
    public String survey_password;
    public boolean make_questions_required;
}
