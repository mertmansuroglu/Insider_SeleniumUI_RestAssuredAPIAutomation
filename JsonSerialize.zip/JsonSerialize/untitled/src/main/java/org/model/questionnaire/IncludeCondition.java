package org.model.questionnaire;
import java.util.ArrayList;

public class IncludeCondition{
    public ArrayList<Object> expressions;
    public ArrayList<Group> groups;
    public String logical_operator;
}
