package org.model.questionnaire;
import java.util.ArrayList;
import java.util.List;
public class LanguageSettings{
    public String default_language;
    public ArrayList<String> supported_languages;
    public String language_source_token;
    public boolean allow_response_language_change;
}
