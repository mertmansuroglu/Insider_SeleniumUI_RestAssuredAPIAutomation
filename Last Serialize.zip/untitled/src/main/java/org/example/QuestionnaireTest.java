package org.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.model.questionnaire.Choice;
import org.model.questionnaire.Item;
import org.model.questionnaire.Page;
import org.model.questionnaire.Questionnaire;

import java.io.IOException;
import java.nio.file.Paths;

public class QuestionnaireTest {
    public static void main(String[] args) throws IOException, NoSuchFieldException, IllegalAccessException {
        ObjectMapper om = new ObjectMapper();
        Questionnaire questionnaire = om.readValue(Paths.get("E:\\KODLAMA_ILE_ILGILI\\Java\\JsonSerialize\\untitled\\src\\main\\java\\org\\example\\Questionnaire.json").toFile(), Questionnaire.class);
        verifyQuestionnaireInfo(questionnaire);

        for (Page page:questionnaire.pages ) {
            switch (page.page_type){
                case  "ContentPage" ->verifyContentPage(page);
                case  "Completion"->verifyCompletionPage(page);
            }
        }
    }

    private static void verifyQuestionnaireInfo(Questionnaire questionnaire) {
        //Todo: Verify Questionnaire info
        //Todo: Verify Pages Count


    }

    private static void verifyCompletionPage(Page page) {
        System.out.println("verifyCompletionPage");
    }

    private static void verifyContentPage(Page page) {
        //Todo: Verify Item count In the page
        //Todo: Verify ...........
        System.out.println("verifyContentPage");
        for (Item item: page.items) {
            switch (item.item_type){
                case  "RadioButtons" ->verifyRadioButtons(item);
                case  "Checkboxes"->verifyCheckboxes(item);
                case  "FileUpload"->verifyFileUpload(item);
                case  "RadioButtonScale"->verifyRadioButtonScale(item);
                case  "SingleLineText"->verifySingleLineText(item);
                case  "MultiLineText"->verifyMultiLineText(item);
                case  "DropdownList"->verifyDropdownList(item);
            }

        }
    }

    private static void verifyDropdownList(Item item) {

        for ( Choice choice:item.choices  ) {

        }
    }

    private static void verifyMultiLineText(Item item) {

    }

    private static void verifySingleLineText(Item item) {

    }

    private static void verifyFileUpload(Item item) {
    }

    private static void verifyRadioButtonScale(Item item) {
    }

    private static void verifyCheckboxes(Item item) {
        for ( Choice choice:item.choices  ) {

        }
    }

    private static void verifyRadioButtons(Item item) {
        for ( Choice choice:item.choices  ) {

        }
    }




}
