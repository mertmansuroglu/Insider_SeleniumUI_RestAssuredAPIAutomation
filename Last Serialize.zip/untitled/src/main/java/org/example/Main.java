package org.example;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.model.questionnaire.Item;
import org.model.questionnaire.Page;
import org.model.questionnaire.Questionnaire;
import org.model.response.Response;
import org.model.response.Responses;
import org.model.user.User;
import org.model.user.Users;

import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException, NoSuchFieldException, IllegalAccessException {
        ObjectMapper om = new ObjectMapper();
        Questionnaire questionnaire = om.readValue(Paths.get("E:\\KODLAMA_ILE_ILGILI\\Java\\JsonSerialize\\untitled\\src\\main\\java\\org\\example\\Questionnaire.json").toFile(), Questionnaire.class);


        Responses responses = om.readValue(Paths.get("E:\\KODLAMA_ILE_ILGILI\\Java\\JsonSerialize\\untitled\\src\\main\\java\\org\\example\\Responses.json").toFile(), Responses.class);
        Users users = om.readValue(Paths.get("E:\\KODLAMA_ILE_ILGILI\\Java\\JsonSerialize\\untitled\\src\\main\\java\\org\\example\\Users.json").toFile(), Users.class);


        List<String> getResponseListByField= getResponseValueByFieldName(responses.responses.get(1),"_6568");
        HashMap<String, List<String>> getAllResponse=getAllResponse(responses.responses.get(1));
        System.out.println("Hello world!");


        for (User user:users.users) {
            verifyUSer(user);
        }

        for (Response response: responses.responses ) {
            verifyResponse(response);
        }





    }

    private static void verifyResponse(Response response) {
    }

    private static void verifyUSer(User user) {
    }

    public static HashMap<String, List<String>> getAllResponse(Response response) throws NoSuchFieldException, IllegalAccessException {
        HashMap<String, List<String>> responseMap=new HashMap<>();
        for (Field fieldName: Response.class.getDeclaredFields()          ) {
            if (fieldName.getName().startsWith("_")){
                String key= fieldName.getName().substring(1, fieldName.getName().length());
                responseMap.put(key,getResponseValueByFieldName(response,fieldName.getName()));
            }
        }
        return responseMap;
    }
    public static List<String> getResponseValueByFieldName(Response response, String fieldName) throws NoSuchFieldException, IllegalAccessException {
        List<String> responseList=new ArrayList<>();
        Field field = Response.class.getField(fieldName);
        addList(responseList,field.get(response));
        return responseList;
    }
    public static void addList(List<String> list,Object obj){
        if (obj instanceof ArrayList) {
            for (Object resp : (ArrayList<String>) obj) {
                addList(list,resp);
            }
        }else {
            list.add((String) obj);
        }
    }



}