package org.example;

import org.model.questionnaire.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class QuestionerieTest2 {
    public static void main(String[] args) throws IOException, NoSuchFieldException, IllegalAccessException {
        Questionnaire   questionnaire=new Questionnaire();
        questionnaire.name="UI dan al";
        questionnaire.flyovers=null;   // UI'dan al
        questionnaire.exhibit_folders=null;// UI'dan gelecek
        //Todo fill questionnaire info
        int pageCount=10;//ui'dan alınacak (getWebElements)
        ArrayList<Page> pages=new ArrayList<>();
        for (int i=0;i<=pageCount;i++){

            Page page=new Page();
            page.title="UI'dan al";
            int itemCount=10;//ui'dan alınacak (getWebElements)
            ArrayList<Item> items=new ArrayList<>();
            for (int j=0;j<=itemCount;j++) {
                Item item=new Item();
                QuestionText questionText=new QuestionText();
                questionText.en_US="Uı'dan Al";
                item.question_text=questionText;
                Subtext subtext=new Subtext();
                item.subtext=subtext;
                item.item_type="UI'dan Gelecek";
                int choiceCount=10;//ui'dan alınacak (getWebElements)
                ArrayList<Choice> choices=new ArrayList<>();
                for (int k=0;k<=choiceCount;k++){
                    Choice choice=new Choice();
                    choice.text=null;//UI'dan al;

                    choices.add(choice);

                }
                  item.choices=choices;
                    items.add(item);

            }
            page.items=items;
            pages.add(page);
        }

        questionnaire.pages=pages;


    }

}
