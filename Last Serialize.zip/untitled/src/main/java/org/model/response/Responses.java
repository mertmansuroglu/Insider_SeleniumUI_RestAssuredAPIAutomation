package org.model.response; 
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class
Responses {
    @JsonProperty("Name") 
    public String name;
    @JsonProperty("Responses") 
    public ArrayList<Response> responses;
}
