package org.model.response; 
import com.fasterxml.jackson.annotation.JsonProperty; 
import java.util.List;
import java.util.ArrayList;
public class Response{
    @JsonProperty("ResponseID") 
    public String responseID;
    @JsonProperty("ResponseGuid") 
    public String responseGuid;
    @JsonProperty("LastEdit") 
    public String lastEdit;
    @JsonProperty("Status") 
    public String status;
    @JsonProperty("IP") 
    public String iP;
    @JsonProperty("Language") 
    public String language;
    @JsonProperty("UniqueIdentifier") 
    public String uniqueIdentifier;
    @JsonProperty("Invitee") 
    public String invitee;
    @JsonProperty("6555") 
    public String _6555;
    @JsonProperty("6556") 
    public ArrayList<String> _6556;
    @JsonProperty("6557") 
    public ArrayList<String> _6557;
    @JsonProperty("6558") 
    public String _6558;
    @JsonProperty("6559") 
    public String _6559;
    @JsonProperty("6560") 
    public String _6560;
    @JsonProperty("6561") 
    public String _6561;
    @JsonProperty("6562") 
    public String _6562;
    @JsonProperty("6563") 
    public String _6563;
    @JsonProperty("6564") 
    public String _6564;
    @JsonProperty("6565") 
    public String _6565;
    @JsonProperty("6566") 
    public String _6566;
    @JsonProperty("6567") 
    public String _6567;
    @JsonProperty("6568") 
    public ArrayList<ArrayList<String>> _6568;
    @JsonProperty("6588") 
    public ArrayList<ArrayList<String>> _6588;
    @JsonProperty("6589") 
    public String _6589;
}
