package org.model.user; 
public class ProfileProperty{
    public String property_name;
    public String value;
}
