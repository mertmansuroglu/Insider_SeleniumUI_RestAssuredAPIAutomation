package org.model.questionnaire;

import java.util.Date;

public class ResponseLimits{
    public Object activation_start_date;
    public Date activation_end_date;
    public Object per_respondent_response_limit;
}
