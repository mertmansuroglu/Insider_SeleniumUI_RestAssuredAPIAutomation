package org.model.questionnaire;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Body{
    @JsonProperty("en-US")
    public String en_US;
}
