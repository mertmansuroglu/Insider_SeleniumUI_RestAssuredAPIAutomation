package org.model.questionnaire;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Subtext{
    @JsonProperty("en-US")
    public String en_US;
}
