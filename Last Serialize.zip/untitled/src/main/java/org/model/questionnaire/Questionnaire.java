package org.model.questionnaire;
import java.util.ArrayList;
import java.util.Date;

public class Questionnaire {
    public String version;
    public Date export_date;
    public String api_url;
    public String created_by;
    public Date created_date;
    public String external_id;
    public String name;
    public String type;
    public String google_analytics_tracking_id;
    public boolean allow_edit_while_active;
    public RespondentSettings respondent_settings;
    public ResponseLimits response_limits;
    public Appearance appearance;
    public LanguageSettings language_settings;
    public ArrayList<Page> pages;
    public ArrayList<Object> customizable_texts;
    public ArrayList<Object> autocomplete_lists;
    public ArrayList<Object> files;
    public ArrayList<Flyover> flyovers;
    public ArrayList<ExhibitFolder> exhibit_folders;
}
