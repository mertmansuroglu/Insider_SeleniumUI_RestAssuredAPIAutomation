package org.model.questionnaire;
public class Expression{
    public int id;
    public LeftOperand left_operand;
    public String operator;
    public RightOperand right_operand;
}
