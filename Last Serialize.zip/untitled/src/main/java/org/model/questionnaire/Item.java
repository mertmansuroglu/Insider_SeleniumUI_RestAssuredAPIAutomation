package org.model.questionnaire;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class Item{
    public int id;
    public String import_id;
    public boolean enabled;
    public int position;
    public String item_type;
    public boolean is_unlimited_columns;
    public boolean is_unlimited_rows;
    public boolean is_required;
    public boolean is_soft_required;
    public Text text;
    public String item_position;
    public String question_text_position;
    public String layout;
    public QuestionText question_text;
    public Subtext subtext;
    public DefaultText default_text;
    public ArrayList<Choice> choices;
    public boolean show_number_labels;
    public boolean allow_none_of_above;
    public IncludeCondition include_condition;
    public ArrayList<String> allowed_file_types;
    public StartText start_text;
    public MidText mid_text;
    public EndText end_text;
    public OtherText other_text;
    public int start_value;
    public int end_value;
    public boolean enable_not_applicable;
    public String answer_format;
    public String custom_format_id;
    public Object max_length;
    public boolean allow_html;
    public Object min_length;
    public Object columns;
    public ArrayList<Row> rows;
    public ArrayList<Element> elements;
    public String row_text_align;
    public String grid_lines;
    public Subject subject;
    public Body body;
    public String format;
    public String from;
    @JsonProperty("to")
    public String myto;
    public String bcc;
    public boolean send_once;
    public boolean include_response_details;
    public boolean show_page_numbers;
    public boolean show_question_numbers;
    public boolean include_message_items;
    public boolean show_hidden_items;
    public int prototype_item_id;
    public String prototype_item_type;
    public String max_value;
    public String min_value;

}
