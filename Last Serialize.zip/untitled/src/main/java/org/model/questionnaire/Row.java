package org.model.questionnaire;
public class Row{
    public int position;
    public String row_type;
    public Text text;
}
